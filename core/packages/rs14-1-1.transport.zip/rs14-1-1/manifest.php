<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8be15fbcba2616840e7c606480d226ce',
      'native_key' => 'rs14',
      'filename' => 'modNamespace/fed94df5ac67d2dd9c1d4fcd425df9c7.vehicle',
      'namespace' => 'rs14',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '95dea9a258f720abd9eb44fb9b5bd269',
      'native_key' => 1,
      'filename' => 'modCategory/6273397aa81e3279f8e746e7aaa166e6.vehicle',
      'namespace' => 'rs14',
    ),
  ),
);